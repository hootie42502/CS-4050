// Implement any C language utility functions you need here

void Nothing()
{
}
