#ifndef _BFS_H
#define _BFS_H

#include "cs4050.h"

#ifdef __cplusplus
extern "C" 
{
#endif
void MST_Kruskal(Vertex * V, int countV, Edge * E, int countE);
#ifdef __cplusplus
}
#endif

#endif
