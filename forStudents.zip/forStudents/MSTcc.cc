#include <iterator>
#include <list>
#include <iostream>
#include "cs4050.h"
#include "MST.h"

void MST_Kruskal(Vertex vertices[], int countVertices, Edge edges[], int countEdges)
{
}
